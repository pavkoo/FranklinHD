友盟 Android SDK 文档(中文)：

http://dev.umeng.com/analytics/android/quick-start
http://dev.umeng.com/analytics/android/release-notes

报表解读：
http://dev.umeng.com/analytics/reports/dashboard

Android SDK Docs(En)：

http://dev.umeng.com/en/analytics/android/installation-guide